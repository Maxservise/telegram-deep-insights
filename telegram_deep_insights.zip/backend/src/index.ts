import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import morgan from 'morgan';

// Загрузка переменных окружения
dotenv.config();

// Инициализация приложения Express
const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(morgan('dev'));

// Маршруты API
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'API работает' });
});

// Подключение к MongoDB (закомментировано до настройки базы данных)
// mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/telegram-insights')
//   .then(() => console.log('Подключено к MongoDB'))
//   .catch(err => console.error('Ошибка подключения к MongoDB:', err));

// Запуск сервера
app.listen(PORT, () => {
  console.log(`Сервер запущен на порту ${PORT}`);
});

export default app;
