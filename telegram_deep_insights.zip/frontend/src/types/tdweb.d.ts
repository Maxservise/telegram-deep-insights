declare module '@wostafa/tdweb';
