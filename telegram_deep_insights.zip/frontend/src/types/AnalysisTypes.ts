// Fix for circular import in AnalysisTypes.ts
export interface MessageAnalysisResult {
  messageId: number;
  userId: number;
  text: string;
  date: Date;
  sentiment: string;
  sentimentScore: number;
}

// Типы для паттернов взаимодействия
export interface UserInteractionPattern {
  userId: number;
  patternType: string;
  value: number;
  description: string;
}

// Типы для результатов анализа чата
export interface ChatAnalysisResult {
  chatId: number;
  chatType: 'personal' | 'group';
  messageCount: number;
  messageAnalysis: MessageAnalysisResult[];
  topics: { topic: string; frequency: number }[];
  interactionPatterns?: UserInteractionPattern[];
  manipulationTactics?: { userId: number; tactic: string; examples: string[] }[];
  groupDynamics?: {
    leaders: number[];
    subgroups: { members: number[]; cohesion: number }[];
    conflicts: { users: number[]; intensity: number }[];
    engagement: { userId: number; level: number }[];
  };
  insights: string[];
}
