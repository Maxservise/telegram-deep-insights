import React, { useEffect, useState } from 'react';
import { Box, Typography, Container, CircularProgress } from '@mui/material';
import telegramService from '../services/TelegramService';

interface AuthContextType {
  isAuthenticated: boolean;
  loading: boolean;
  error: string | null;
  login: (phoneNumber: string) => Promise<void>;
  verifyCode: (code: string) => Promise<void>;
  verifyPassword: (password: string) => Promise<void>;
  logout: () => Promise<void>;
}

export const AuthContext = React.createContext<AuthContextType>({
  isAuthenticated: false,
  loading: false,
  error: null,
  login: async () => {},
  verifyCode: async () => {},
  verifyPassword: async () => {},
  logout: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const initAuth = async () => {
      try {
        await telegramService.initialize();
        
        // Проверяем, авторизован ли пользователь
        const isAuth = telegramService.isAuthenticated();
        setIsAuthenticated(isAuth);
      } catch (err: any) {
        setError(err.message || 'Ошибка инициализации');
        console.error('Auth initialization error:', err);
      } finally {
        setLoading(false);
      }
    };

    // Подписываемся на изменения состояния авторизации
    const handleAuthStateChanged = (authState: string) => {
      if (authState === 'authorizationStateReady') {
        setIsAuthenticated(true);
      } else {
        setIsAuthenticated(false);
      }
    };

    telegramService.on('authStateChanged', handleAuthStateChanged);
    initAuth();

    return () => {
      telegramService.off('authStateChanged', handleAuthStateChanged);
    };
  }, []);

  const login = async (phoneNumber: string) => {
    setError(null);
    setLoading(true);
    try {
      await telegramService.sendPhoneNumber(phoneNumber);
    } catch (err: any) {
      setError(err.message || 'Ошибка отправки номера телефона');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const verifyCode = async (code: string) => {
    setError(null);
    setLoading(true);
    try {
      await telegramService.sendVerificationCode(code);
    } catch (err: any) {
      setError(err.message || 'Неверный код подтверждения');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const verifyPassword = async (password: string) => {
    setError(null);
    setLoading(true);
    try {
      await telegramService.sendPassword(password);
    } catch (err: any) {
      setError(err.message || 'Неверный пароль');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    setError(null);
    setLoading(true);
    try {
      await telegramService.logout();
      setIsAuthenticated(false);
    } catch (err: any) {
      setError(err.message || 'Ошибка при выходе из аккаунта');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        loading,
        error,
        login,
        verifyCode,
        verifyPassword,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => React.useContext(AuthContext);

export const AuthGuard: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <Container maxWidth="sm">
        <Box sx={{ mt: 8, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <CircularProgress />
          <Typography variant="body1" sx={{ mt: 2 }}>
            Проверка авторизации...
          </Typography>
        </Box>
      </Container>
    );
  }

  return <>{children}</>;
};
