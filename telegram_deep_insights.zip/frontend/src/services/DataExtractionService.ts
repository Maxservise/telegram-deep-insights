import telegramService from '../services/TelegramService';

class DataExtractionService {
  // Получение списка всех чатов пользователя
  async getAllChats(limit: number = 100): Promise<any[]> {
    try {
      return await telegramService.getChats(limit);
    } catch (error) {
      console.error('Error fetching chats:', error);
      throw error;
    }
  }

  // Получение истории сообщений для конкретного чата
  async getChatHistory(chatId: number, limit: number = 100): Promise<any[]> {
    try {
      return await telegramService.getChatHistory(chatId, limit);
    } catch (error) {
      console.error(`Error fetching chat history for chat ${chatId}:`, error);
      throw error;
    }
  }

  // Получение информации о пользователях в групповом чате
  async getChatMembers(chatId: number): Promise<any[]> {
    try {
      const result = await telegramService.getClient().send({
        '@type': 'getChatMembers',
        chat_id: chatId,
        offset: 0,
        limit: 200,
        filter: {
          '@type': 'chatMembersFilterMembers'
        }
      });
      return result.members || [];
    } catch (error) {
      console.error(`Error fetching chat members for chat ${chatId}:`, error);
      throw error;
    }
  }

  // Получение информации о пользователе
  async getUserInfo(userId: number): Promise<any> {
    try {
      return await telegramService.getClient().send({
        '@type': 'getUser',
        user_id: userId
      });
    } catch (error) {
      console.error(`Error fetching user info for user ${userId}:`, error);
      throw error;
    }
  }

  // Получение информации о чате
  async getChatInfo(chatId: number): Promise<any> {
    try {
      return await telegramService.getChat(chatId);
    } catch (error) {
      console.error(`Error fetching chat info for chat ${chatId}:`, error);
      throw error;
    }
  }

  // Подготовка данных для анализа личного чата
  async preparePersonalChatData(chatId: number): Promise<any> {
    try {
      const chatInfo = await this.getChatInfo(chatId);
      const messages = await this.getChatHistory(chatId, 1000);
      
      // Получаем информацию о собеседнике
      let otherUserId = 0;
      if (chatInfo.type['@type'] === 'chatTypePrivate') {
        otherUserId = chatInfo.type.user_id;
      }
      
      const otherUserInfo = otherUserId ? await this.getUserInfo(otherUserId) : null;
      
      return {
        chatInfo,
        messages,
        otherUserInfo
      };
    } catch (error) {
      console.error(`Error preparing personal chat data for chat ${chatId}:`, error);
      throw error;
    }
  }

  // Подготовка данных для анализа группового чата
  async prepareGroupChatData(chatId: number): Promise<any> {
    try {
      const chatInfo = await this.getChatInfo(chatId);
      const messages = await this.getChatHistory(chatId, 1000);
      const members = await this.getChatMembers(chatId);
      
      // Получаем информацию о каждом участнике
      const memberDetails = await Promise.all(
        members.map(async (member: any) => {
          const userInfo = await this.getUserInfo(member.user_id);
          return {
            ...member,
            userInfo
          };
        })
      );
      
      return {
        chatInfo,
        messages,
        members: memberDetails
      };
    } catch (error) {
      console.error(`Error preparing group chat data for chat ${chatId}:`, error);
      throw error;
    }
  }

  // Определение типа чата и подготовка соответствующих данных
  async prepareChatDataForAnalysis(chatId: number): Promise<any> {
    try {
      const chatInfo = await this.getChatInfo(chatId);
      
      if (chatInfo.type['@type'] === 'chatTypePrivate') {
        return this.preparePersonalChatData(chatId);
      } else if (
        chatInfo.type['@type'] === 'chatTypeBasicGroup' || 
        chatInfo.type['@type'] === 'chatTypeSupergroup'
      ) {
        return this.prepareGroupChatData(chatId);
      } else {
        throw new Error(`Unsupported chat type: ${chatInfo.type['@type']}`);
      }
    } catch (error) {
      console.error(`Error preparing chat data for analysis for chat ${chatId}:`, error);
      throw error;
    }
  }

  // Экспорт данных чата в JSON формат
  exportChatDataToJson(chatData: any): string {
    try {
      return JSON.stringify(chatData, null, 2);
    } catch (error) {
      console.error('Error exporting chat data to JSON:', error);
      throw error;
    }
  }
}

// Создание и экспорт синглтона сервиса
const dataExtractionService = new DataExtractionService();
export default dataExtractionService;
