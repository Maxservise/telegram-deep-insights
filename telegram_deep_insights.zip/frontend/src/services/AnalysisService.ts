import { MessageAnalysisResult, ChatAnalysisResult, UserInteractionPattern } from '../types/AnalysisTypes';

class AnalysisService {
  // Анализ эмоционального тона сообщений
  analyzeSentiment(text: string): { score: number; label: string } {
    // Упрощенный алгоритм анализа тональности
    const positiveWords = ['хорошо', 'отлично', 'супер', 'класс', 'рад', 'люблю', 'нравится', 'спасибо', 'благодарю', '👍', '😊', '❤️'];
    const negativeWords = ['плохо', 'ужасно', 'отстой', 'ненавижу', 'раздражает', 'злюсь', 'грустно', 'жаль', 'извини', '👎', '😠', '😢'];
    
    const lowerText = text.toLowerCase();
    let score = 0;
    
    positiveWords.forEach(word => {
      const regex = new RegExp(word, 'gi');
      const matches = lowerText.match(regex);
      if (matches) score += matches.length;
    });
    
    negativeWords.forEach(word => {
      const regex = new RegExp(word, 'gi');
      const matches = lowerText.match(regex);
      if (matches) score -= matches.length;
    });
    
    let label = 'нейтральный';
    if (score > 2) label = 'позитивный';
    else if (score < -2) label = 'негативный';
    
    return { score, label };
  }
  
  // Анализ тем сообщений
  analyzeTopics(messages: any[]): { topic: string; frequency: number }[] {
    const topics: Record<string, number> = {};
    const topicKeywords: Record<string, string[]> = {
      'работа': ['работа', 'проект', 'задача', 'дедлайн', 'совещание', 'коллега', 'босс', 'офис'],
      'семья': ['семья', 'дети', 'родители', 'мама', 'папа', 'брат', 'сестра', 'муж', 'жена'],
      'отдых': ['отдых', 'отпуск', 'путешествие', 'поездка', 'выходные', 'развлечение', 'кино', 'ресторан'],
      'здоровье': ['здоровье', 'болезнь', 'врач', 'лекарство', 'самочувствие', 'больница', 'аптека'],
      'финансы': ['деньги', 'зарплата', 'бюджет', 'кредит', 'счет', 'оплата', 'покупка', 'цена'],
      'технологии': ['компьютер', 'телефон', 'приложение', 'программа', 'интернет', 'сайт', 'гаджет']
    };
    
    // Инициализация счетчиков тем
    Object.keys(topicKeywords).forEach(topic => {
      topics[topic] = 0;
    });
    
    // Подсчет упоминаний ключевых слов для каждой темы
    messages.forEach(message => {
      if (message.content?.text?.text) {
        const text = message.content.text.text.toLowerCase();
        
        Object.entries(topicKeywords).forEach(([topic, keywords]) => {
          keywords.forEach(keyword => {
            if (text.includes(keyword)) {
              topics[topic]++;
            }
          });
        });
      }
    });
    
    // Преобразование в массив и сортировка по частоте
    return Object.entries(topics)
      .map(([topic, frequency]) => ({ topic, frequency }))
      .sort((a, b) => b.frequency - a.frequency);
  }
  
  // Анализ паттернов взаимодействия
  analyzeInteractionPatterns(messages: any[]): UserInteractionPattern[] {
    const patterns: UserInteractionPattern[] = [];
    
    // Анализ времени ответа
    const responseTimesByUser: Record<number, number[]> = {};
    let lastMessageTime: Record<string, number> = {};
    
    messages.sort((a, b) => a.date - b.date).forEach(message => {
      const userId = message.sender_id?.user_id;
      const messageTime = message.date;
      
      if (userId && messageTime) {
        // Если уже есть предыдущее сообщение от другого пользователя
        Object.entries(lastMessageTime).forEach(([otherUserId, time]) => {
          if (otherUserId !== userId.toString()) {
            const responseTime = messageTime - time;
            
            if (!responseTimesByUser[userId]) {
              responseTimesByUser[userId] = [];
            }
            
            if (responseTime > 0 && responseTime < 86400) { // Исключаем ответы дольше суток
              responseTimesByUser[userId].push(responseTime);
            }
          }
        });
        
        lastMessageTime[userId] = messageTime;
      }
    });
    
    // Вычисление среднего времени ответа для каждого пользователя
    Object.entries(responseTimesByUser).forEach(([userId, times]) => {
      if (times.length > 0) {
        const avgResponseTime = times.reduce((sum, time) => sum + time, 0) / times.length;
        patterns.push({
          userId: parseInt(userId),
          patternType: 'responseTime',
          value: avgResponseTime,
          description: `Среднее время ответа: ${formatTime(avgResponseTime)}`
        });
      }
    });
    
    // Анализ инициативы в общении
    const initiativeByUser: Record<number, number> = {};
    let lastUserId: number | null = null;
    
    messages.forEach(message => {
      const userId = message.sender_id?.user_id;
      
      if (userId) {
        // Если это новая цепочка сообщений (другой пользователь или прошло много времени)
        if (lastUserId !== userId) {
          if (!initiativeByUser[userId]) {
            initiativeByUser[userId] = 0;
          }
          initiativeByUser[userId]++;
        }
        
        lastUserId = userId;
      }
    });
    
    // Добавление паттернов инициативы
    Object.entries(initiativeByUser).forEach(([userId, count]) => {
      patterns.push({
        userId: parseInt(userId),
        patternType: 'initiative',
        value: count,
        description: `Инициировал общение ${count} раз`
      });
    });
    
    // Анализ игнорирования сообщений
    const messageCountByUser: Record<number, number> = {};
    const ignoredMessagesByUser: Record<number, number> = {};
    
    messages.forEach(message => {
      const userId = message.sender_id?.user_id;
      
      if (userId) {
        if (!messageCountByUser[userId]) {
          messageCountByUser[userId] = 0;
        }
        messageCountByUser[userId]++;
      }
    });
    
    // Определение игнорирования по отсутствию ответа в течение длительного времени
    let currentUserId: number | null = null;
    let unansweredCount = 0;
    
    messages.sort((a, b) => a.date - b.date).forEach(message => {
      const userId = message.sender_id?.user_id;
      
      if (userId) {
        if (currentUserId && currentUserId !== userId) {
          unansweredCount = 0; // Сбрасываем счетчик, так как получен ответ
        } else if (currentUserId === userId) {
          unansweredCount++;
          
          if (unansweredCount >= 3) { // Если 3+ сообщения подряд без ответа
            if (!ignoredMessagesByUser[userId]) {
              ignoredMessagesByUser[userId] = 0;
            }
            ignoredMessagesByUser[userId]++;
          }
        }
        
        currentUserId = userId;
      }
    });
    
    // Добавление паттернов игнорирования
    Object.entries(ignoredMessagesByUser).forEach(([userId, count]) => {
      patterns.push({
        userId: parseInt(userId),
        patternType: 'ignored',
        value: count,
        description: `Сообщения игнорировались ${count} раз`
      });
    });
    
    return patterns;
  }
  
  // Анализ манипулятивных тактик
  analyzeManipulationTactics(messages: any[]): { userId: number; tactic: string; examples: string[] }[] {
    const manipulationTactics: Record<string, string[]> = {
      'gaslighting': ['ты неправильно помнишь', 'этого не было', 'тебе показалось', 'ты все выдумываешь', 'ты преувеличиваешь'],
      'guilt_tripping': ['после всего что я для тебя сделал', 'ты мне должен', 'я столько для тебя делаю', 'ты меня расстраиваешь'],
      'deflection': ['давай не будем об этом', 'это не важно', 'ты меняешь тему', 'это не имеет значения'],
      'silent_treatment': ['...', '.', '🤐', '😶'],
      'love_bombing': ['ты самый лучший', 'я не могу без тебя', 'ты идеальный', 'ты мое все', '❤️❤️❤️']
    };
    
    const results: Record<number, Record<string, string[]>> = {};
    
    messages.forEach(message => {
      const userId = message.sender_id?.user_id;
      const text = message.content?.text?.text;
      
      if (userId && text) {
        const lowerText = text.toLowerCase();
        
        Object.entries(manipulationTactics).forEach(([tactic, phrases]) => {
          phrases.forEach(phrase => {
            if (lowerText.includes(phrase.toLowerCase())) {
              if (!results[userId]) {
                results[userId] = {};
              }
              
              if (!results[userId][tactic]) {
                results[userId][tactic] = [];
              }
              
              if (results[userId][tactic].length < 3) { // Ограничиваем количество примеров
                results[userId][tactic].push(text);
              }
            }
          });
        });
      }
    });
    
    // Преобразование результатов в нужный формат
    const formattedResults: { userId: number; tactic: string; examples: string[] }[] = [];
    
    Object.entries(results).forEach(([userId, tactics]) => {
      Object.entries(tactics).forEach(([tactic, examples]) => {
        formattedResults.push({
          userId: parseInt(userId),
          tactic: formatTacticName(tactic),
          examples
        });
      });
    });
    
    return formattedResults;
  }
  
  // Анализ групповой динамики
  analyzeGroupDynamics(messages: any[], members: any[]): {
    leaders: number[];
    subgroups: { members: number[]; cohesion: number }[];
    conflicts: { users: number[]; intensity: number }[];
    engagement: { userId: number; level: number }[];
  } {
    // Определение лидеров по количеству сообщений и реакций на них
    const messageCountByUser: Record<number, number> = {};
    const reactionsReceivedByUser: Record<number, number> = {};
    
    messages.forEach(message => {
      const userId = message.sender_id?.user_id;
      
      if (userId) {
        if (!messageCountByUser[userId]) {
          messageCountByUser[userId] = 0;
        }
        messageCountByUser[userId]++;
        
        // Подсчет реакций
        if (message.reactions && message.reactions.reactions) {
          if (!reactionsReceivedByUser[userId]) {
            reactionsReceivedByUser[userId] = 0;
          }
          message.reactions.reactions.forEach((reaction: any) => {
            reactionsReceivedByUser[userId] += reaction.count || 0;
          });
        }
      }
    });
    
    // Вычисление "лидерского" рейтинга
    const leadershipScore: Record<number, number> = {};
    
    Object.entries(messageCountByUser).forEach(([userId, count]) => {
      const userIdNum = parseInt(userId);
      leadershipScore[userIdNum] = count * 0.5 + (reactionsReceivedByUser[userIdNum] || 0) * 1.5;
    });
    
    // Определение лидеров (топ 20% пользователей по рейтингу)
    const sortedLeaders = Object.entries(leadershipScore)
      .sort(([, a], [, b]) => b - a)
      .map(([userId]) => parseInt(userId));
    
    const leaderCount = Math.max(1, Math.ceil(sortedLeaders.length * 0.2));
    const leaders = sortedLeaders.slice(0, leaderCount);
    
    // Определение подгрупп на основе взаимных реакций
    const interactionMatrix: Record<number, Record<number, number>> = {};
    
    // Инициализация матрицы взаимодействий
    members.forEach((member: any) => {
      const userId = member.user_id;
      interactionMatrix[userId] = {};
      
      members.forEach((otherMember: any) => {
        const otherUserId = otherMember.user_id;
        if (userId !== otherUserId) {
          interactionMatrix[userId][otherUserId] = 0;
        }
      });
    });
    
    // Заполнение матрицы взаимодействий
    messages.forEach(message => {
      const senderId = message.sender_id?.user_id;
      
      if (senderId && message.reactions && message.reactions.reactions) {
        message.reactions.reactions.forEach((reaction: any) => {
          if (reaction.recent_reaction_senders) {
            reaction.recent_reaction_senders.forEach((sender: any) => {
              const reactorId = sender.user_id;
              
              if (reactorId && reactorId !== senderId) {
                if (interactionMatrix[senderId]) {
                  interactionMatrix[senderId][reactorId] = (interactionMatrix[senderId][reactorId] || 0) + 1;
                }
                if (interactionMatrix[reactorId]) {
                  interactionMatrix[reactorId][senderId] = (interactionMatrix[reactorId][senderId] || 0) + 1;
                }
              }
            });
          }
        });
      }
    });
    
    // Простой алгоритм кластеризации для выявления подгрупп
    const subgroups: { members: number[]; cohesion: number }[] = [];
    const assignedUsers = new Set<number>();
    
    // Для каждого пользователя находим его "ближайших друзей"
    Object.keys(interactionMatrix).forEach(userIdStr => {
      const userId = parseInt(userIdStr);
      
      if (!assignedUsers.has(userId)) {
        const interactions = interactionMatrix[userId];
        const closeUsers = Object.entries(interactions)
          .filter(([, strength]) => strength > 5) // Порог силы взаимодействия
          .map(([otherId]) => parseInt(otherId))
          .filter(id => !assignedUsers.has(id));
        
        if (closeUsers.length > 0) {
          const subgroupMembers = [userId, ...closeUsers];
          
          // Вычисление силы сплоченности подгруппы
          let totalInteractions = 0;
          let possibleInteractions = 0;
          
          subgroupMembers.forEach(member => {
            subgroupMembers.forEach(otherMember => {
              if (member !== otherMember) {
                if (interactionMatrix[member] && interactionMatrix[member][otherMember] !== undefined) {
                  totalInteractions += interactionMatrix[member][otherMember];
                }
                possibleInteractions++;
              }
            });
          });
          
          const cohesion = possibleInteractions > 0 ? totalInteractions / possibleInteractions : 0;
          
          subgroups.push({
            members: subgroupMembers,
            cohesion
          });
          
          // Отмечаем пользователей как уже распределенных
          subgroupMembers.forEach(member => {
            assignedUsers.add(member);
          });
        }
      }
    });
    
    // Определение конфликтов на основе негативных взаимодействий
    const conflicts: { users: number[]; intensity: number }[] = [];
    const negativeEmojis = ['👎', '😠', '😡', '🤬', '😤', '😒', '🙄'];
    
    messages.forEach(message => {
      const senderId = message.sender_id?.user_id;
      const text = message.content?.text?.text;
      
      if (senderId && text) {
        // Поиск упоминаний пользователей и негативных эмоций в одном сообщении
        const mentionedUsers: number[] = [];
        
        // Простая эвристика для поиска упоминаний (можно улучшить)
        members.forEach((member: any) => {
          if (member.userInfo && member.userInfo.username) {
            if (text.includes(`@${member.userInfo.username}`)) {
              mentionedUsers.push(member.user_id);
            }
          }
          
          if (member.userInfo && member.userInfo.first_name) {
            if (text.includes(member.userInfo.first_name)) {
              mentionedUsers.push(member.user_id);
            }
          }
        });
        
        // Проверка на наличие негативных эмоций
        const hasNegativeEmotions = negativeEmojis.some(emoji => text.includes(emoji)) || 
                                    this.analyzeSentiment(text).score < -2;
        
        if (hasNegativeEmotions && mentionedUsers.length > 0) {
          mentionedUsers.forEach(userId => {
            if (userId !== senderId) {
              // Проверяем, существует ли уже такой конфликт
              const existingConflict = conflicts.find(conflict => 
                conflict.users.includes(senderId) && conflict.users.includes(userId)
              );
              
              if (existingConflict) {
                existingConflict.intensity++;
              } else {
                conflicts.push({
                  users: [senderId, userId],
                  intensity: 1
                });
              }
            }
          });
        }
      }
    });
    
    // Определение уровня вовлеченности пользователей
    const engagement: { userId: number; level: number }[] = [];
    
    members.forEach((member: any) => {
      const userId = member.user_id;
      const messageCount = messageCountByUser[userId] || 0;
      const reactionsReceived = reactionsReceivedByUser[userId] || 0;
      
      // Вычисление уровня вовлеченности (от 0 до 10)
      let engagementLevel = 0;
      
      if (messages.length > 0) {
        // Нормализация по количеству сообщений в чате
        const normalizedMessageCount = Math.min(1, messageCount / (messages.length * 0.2));
        const normalizedReactions = Math.min(1, reactionsReceived / (messageCount * 2 || 1));
        
        engagementLevel = Math.round((normalizedMessageCount * 0.7 + normalizedReactions * 0.3) * 10);
      }
      
      engagement.push({
        userId,
        level: engagementLevel
      });
    });
    
    return {
      leaders,
      subgroups,
      conflicts,
      engagement: engagement.sort((a, b) => b.level - a.level)
    };
  }
  
  // Анализ личного чата
  analyzePersonalChat(chatData: any): ChatAnalysisResult {
    const { messages, otherUserInfo } = chatData;
    
    // Анализ сообщений
    const messageAnalysis: MessageAnalysisResult[] = [];
    let totalMessages = 0;
    let userMessageCount = 0;
    let otherUserMessageCount = 0;
    
    messages.forEach((message: any) => {
      if (message.content?.text?.text) {
        totalMessages++;
        
        const userId = message.sender_id?.user_id;
        const isOtherUser = otherUserInfo && userId === otherUserInfo.id;
        
        if (isOtherUser) {
          otherUserMessageCount++;
        } else {
          userMessageCount++;
        }
        
        const sentiment = this.analyzeSentiment(message.content.text.text);
        
        messageAnalysis.push({
          messageId: message.id,
          userId,
          text: message.content.text.text,
          date: new Date(message.date * 1000),
          sentiment: sentiment.label,
          sentimentScore: sentiment.score
        });
      }
    });
    
    // Анализ тем
    const topics = this.analyzeTopics(messages);
    
    // Анализ паттернов взаимодействия
    const interactionPatterns = this.analyzeInteractionPatterns(messages);
    
    // Анализ манипулятивных тактик
    const manipulationTactics = this.analyzeManipulationTactics(messages);
    
    // Формирование инсайтов
    const insights: string[] = [];
    
    // Инсайт о балансе общения
    if (totalMessages > 10) {
      const userPercentage = (userMessageCount / totalMessages) * 100;
      const otherUserPercentage = (otherUserMessageCount / totalMessages) * 100;
      
      if (userPercentage > 70) {
        insights.push(`Вы инициируете ${Math.round(userPercentage)}% общения. Возможно, вы более заинтересованы в общении, чем собеседник.`);
      } else if (otherUserPercentage > 70) {
        insights.push(`Ваш собеседник инициирует ${Math.round(otherUserPercentage)}% общения. Возможно, он более заинтересован в общении.`);
      } else {
        insights.push(`Общение сбалансировано: вы отправляете ${Math.round(userPercentage)}% сообщений, ваш собеседник - ${Math.round(otherUserPercentage)}%.`);
      }
    }
    
    // Инсайт о времени ответа
    const userResponsePattern = interactionPatterns.find(p => 
      otherUserInfo && p.userId !== otherUserInfo.id && p.patternType === 'responseTime'
    );
    
    const otherUserResponsePattern = interactionPatterns.find(p => 
      otherUserInfo && p.userId === otherUserInfo.id && p.patternType === 'responseTime'
    );
    
    if (userResponsePattern && otherUserResponsePattern) {
      const userTime = userResponsePattern.value;
      const otherUserTime = otherUserResponsePattern.value;
      
      if (userTime > otherUserTime * 2) {
        insights.push(`Вы отвечаете значительно медленнее (${formatTime(userTime)}), чем ваш собеседник (${formatTime(otherUserTime)}). Это может указывать на разный уровень приоритета общения.`);
      } else if (otherUserTime > userTime * 2) {
        insights.push(`Ваш собеседник отвечает значительно медленнее (${formatTime(otherUserTime)}), чем вы (${formatTime(userTime)}). Это может указывать на разный уровень приоритета общения.`);
      }
    }
    
    // Инсайт о манипуляциях
    if (manipulationTactics.length > 0) {
      const userManipulations = manipulationTactics.filter(m => otherUserInfo && m.userId !== otherUserInfo.id);
      const otherUserManipulations = manipulationTactics.filter(m => otherUserInfo && m.userId === otherUserInfo.id);
      
      if (otherUserManipulations.length > 0) {
        const tactics = Array.from(new Set(otherUserManipulations.map(m => m.tactic))).join(', ');
        insights.push(`Обнаружены потенциальные манипулятивные тактики со стороны собеседника: ${tactics}.`);
      }
      
      if (userManipulations.length > 0) {
        const tactics = Array.from(new Set(userManipulations.map(m => m.tactic))).join(', ');
        insights.push(`Обнаружены потенциальные манипулятивные тактики в ваших сообщениях: ${tactics}.`);
      }
    }
    
    // Инсайт о темах общения
    if (topics.length > 0) {
      const topThree = topics.slice(0, 3).filter(t => t.frequency > 0);
      if (topThree.length > 0) {
        insights.push(`Основные темы вашего общения: ${topThree.map(t => t.topic).join(', ')}.`);
      }
    }
    
    return {
      chatId: chatData.chatInfo.id,
      chatType: 'personal',
      messageCount: totalMessages,
      messageAnalysis,
      topics,
      interactionPatterns,
      manipulationTactics,
      insights
    };
  }
  
  // Анализ группового чата
  analyzeGroupChat(chatData: any): ChatAnalysisResult {
    const { messages, members } = chatData;
    
    // Анализ сообщений
    const messageAnalysis: MessageAnalysisResult[] = [];
    
    messages.forEach((message: any) => {
      if (message.content?.text?.text) {
        const userId = message.sender_id?.user_id;
        const sentiment = this.analyzeSentiment(message.content.text.text);
        
        messageAnalysis.push({
          messageId: message.id,
          userId,
          text: message.content.text.text,
          date: new Date(message.date * 1000),
          sentiment: sentiment.label,
          sentimentScore: sentiment.score
        });
      }
    });
    
    // Анализ тем
    const topics = this.analyzeTopics(messages);
    
    // Анализ групповой динамики
    const groupDynamics = this.analyzeGroupDynamics(messages, members);
    
    // Формирование инсайтов
    const insights: string[] = [];
    
    // Инсайт о лидерах группы
    if (groupDynamics.leaders.length > 0) {
      const leaderNames = groupDynamics.leaders.map(leaderId => {
        const member = members.find((m: any) => m.user_id === leaderId);
        return member?.userInfo?.first_name || `Участник ${leaderId}`;
      }).join(', ');
      
      insights.push(`Неформальные лидеры чата: ${leaderNames}.`);
    }
    
    // Инсайт о подгруппах
    if (groupDynamics.subgroups.length > 0) {
      insights.push(`В чате выявлено ${groupDynamics.subgroups.length} подгрупп участников, которые активно взаимодействуют между собой.`);
      
      // Детали о самой сплоченной подгруппе
      const mostCohesiveGroup = [...groupDynamics.subgroups].sort((a, b) => b.cohesion - a.cohesion)[0];
      if (mostCohesiveGroup) {
        const memberNames = mostCohesiveGroup.members.map(memberId => {
          const member = members.find((m: any) => m.user_id === memberId);
          return member?.userInfo?.first_name || `Участник ${memberId}`;
        }).join(', ');
        
        insights.push(`Самая сплоченная подгруппа: ${memberNames}.`);
      }
    }
    
    // Инсайт о конфликтах
    if (groupDynamics.conflicts.length > 0) {
      insights.push(`Обнаружено ${groupDynamics.conflicts.length} потенциальных конфликтов между участниками.`);
      
      // Детали о самом интенсивном конфликте
      const mostIntenseConflict = [...groupDynamics.conflicts].sort((a, b) => b.intensity - a.intensity)[0];
      if (mostIntenseConflict) {
        const user1 = members.find((m: any) => m.user_id === mostIntenseConflict.users[0]);
        const user2 = members.find((m: any) => m.user_id === mostIntenseConflict.users[1]);
        
        const user1Name = user1?.userInfo?.first_name || `Участник ${mostIntenseConflict.users[0]}`;
        const user2Name = user2?.userInfo?.first_name || `Участник ${mostIntenseConflict.users[1]}`;
        
        insights.push(`Наиболее выраженный конфликт наблюдается между ${user1Name} и ${user2Name}.`);
      }
    }
    
    // Инсайт о вовлеченности
    if (groupDynamics.engagement.length > 0) {
      const highlyEngaged = groupDynamics.engagement.filter(e => e.level >= 8);
      const lowEngaged = groupDynamics.engagement.filter(e => e.level <= 2);
      
      if (highlyEngaged.length > 0) {
        const names = highlyEngaged.map(e => {
          const member = members.find((m: any) => m.user_id === e.userId);
          return member?.userInfo?.first_name || `Участник ${e.userId}`;
        }).join(', ');
        
        insights.push(`Наиболее активные участники: ${names}.`);
      }
      
      if (lowEngaged.length > 0 && members.length > 5) {
        const count = lowEngaged.length;
        insights.push(`${count} участников проявляют низкую активность в чате.`);
      }
    }
    
    // Инсайт о темах общения
    if (topics.length > 0) {
      const topThree = topics.slice(0, 3).filter(t => t.frequency > 0);
      if (topThree.length > 0) {
        insights.push(`Основные темы обсуждения в группе: ${topThree.map(t => t.topic).join(', ')}.`);
      }
    }
    
    return {
      chatId: chatData.chatInfo.id,
      chatType: 'group',
      messageCount: messages.length,
      messageAnalysis,
      topics,
      groupDynamics,
      insights
    };
  }
  
  // Общий метод анализа чата
  analyzeChatData(chatData: any): ChatAnalysisResult {
    if (chatData.chatInfo.type['@type'] === 'chatTypePrivate') {
      return this.analyzePersonalChat(chatData);
    } else {
      return this.analyzeGroupChat(chatData);
    }
  }
}

// Вспомогательные функции
function formatTime(seconds: number): string {
  if (seconds < 60) {
    return `${Math.round(seconds)} сек.`;
  } else if (seconds < 3600) {
    return `${Math.round(seconds / 60)} мин.`;
  } else {
    return `${Math.round(seconds / 3600)} ч.`;
  }
}

function formatTacticName(tactic: string): string {
  switch (tactic) {
    case 'gaslighting': return 'Газлайтинг';
    case 'guilt_tripping': return 'Манипуляция чувством вины';
    case 'deflection': return 'Уход от темы';
    case 'silent_treatment': return 'Игнорирование';
    case 'love_bombing': return 'Бомбардировка любовью';
    default: return tactic;
  }
}

// Создание и экспорт синглтона сервиса
const analysisService = new AnalysisService();
export default analysisService;
