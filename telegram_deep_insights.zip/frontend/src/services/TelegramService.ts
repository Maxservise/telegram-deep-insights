import TdClient from '../mocks/TdWebMock';

// Конфигурация TDLib
const tdLibConfig = {
  apiId: 1234567, // Заменить на реальный API ID
  apiHash: 'abcdef1234567890abcdef1234567890', // Заменить на реальный API Hash
  useTestDc: false,
  deviceModel: 'Web Browser',
  systemVersion: 'Unknown',
  applicationVersion: '1.0.0',
  useSecretChats: false,
  systemLanguageCode: 'ru',
  databaseDirectory: '/telegram-data',
  filesDirectory: '/telegram-files',
  useFileDatabase: true,
  useChatInfoDatabase: true,
  useMessageDatabase: true,
  enableStorageOptimizer: true,
};

class TelegramService {
  private client: any;
  private isInitialized: boolean = false;
  private authState: string = 'authorizationStateWaitPhoneNumber';
  private updateHandlers: Map<string, Function[]> = new Map();

  constructor() {
    this.client = new TdClient({
      onUpdate: this.handleUpdate.bind(this),
      instanceName: 'telegram-deep-insights',
      jsLogVerbosityLevel: 'warning',
      logVerbosityLevel: 2,
    });
  }

  // Инициализация TDLib
  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      await this.client.send({
        '@type': 'setTdlibParameters',
        parameters: tdLibConfig,
      });
      this.isInitialized = true;
      console.log('TDLib initialized successfully');
    } catch (error) {
      console.error('Failed to initialize TDLib:', error);
      throw error;
    }
  }

  // Обработка обновлений от TDLib
  private handleUpdate(update: any): void {
    console.log('Received update:', update);

    // Обработка обновлений состояния авторизации
    if (update['@type'] === 'updateAuthorizationState') {
      this.authState = update.authorization_state['@type'];
      this.notifyUpdateHandlers('authStateChanged', this.authState);
    }

    // Вызов обработчиков для соответствующего типа обновления
    this.notifyUpdateHandlers(update['@type'], update);
  }

  // Отправка номера телефона для авторизации
  async sendPhoneNumber(phoneNumber: string): Promise<void> {
    try {
      await this.client.send({
        '@type': 'setAuthenticationPhoneNumber',
        phone_number: phoneNumber,
        settings: {
          '@type': 'phoneNumberAuthenticationSettings',
          allow_flash_call: false,
          allow_missed_call: false,
          allow_sms_retriever_api: false,
          authentication_tokens: [],
          is_current_phone_number: true,
        },
      });
      console.log('Phone number sent successfully');
    } catch (error) {
      console.error('Failed to send phone number:', error);
      throw error;
    }
  }

  // Отправка кода подтверждения
  async sendVerificationCode(code: string): Promise<void> {
    try {
      await this.client.send({
        '@type': 'checkAuthenticationCode',
        code: code,
      });
      console.log('Verification code sent successfully');
    } catch (error) {
      console.error('Failed to send verification code:', error);
      throw error;
    }
  }

  // Отправка пароля (для двухфакторной аутентификации)
  async sendPassword(password: string): Promise<void> {
    try {
      await this.client.send({
        '@type': 'checkAuthenticationPassword',
        password: password,
      });
      console.log('Password sent successfully');
    } catch (error) {
      console.error('Failed to send password:', error);
      throw error;
    }
  }

  // Выход из аккаунта
  async logout(): Promise<void> {
    try {
      await this.client.send({
        '@type': 'logOut',
      });
      console.log('Logged out successfully');
    } catch (error) {
      console.error('Failed to logout:', error);
      throw error;
    }
  }

  // Получение текущего состояния авторизации
  getAuthState(): string {
    return this.authState;
  }

  // Проверка, авторизован ли пользователь
  isAuthenticated(): boolean {
    return this.authState === 'authorizationStateReady';
  }

  // Регистрация обработчика обновлений
  on(updateType: string, handler: Function): void {
    if (!this.updateHandlers.has(updateType)) {
      this.updateHandlers.set(updateType, []);
    }
    this.updateHandlers.get(updateType)?.push(handler);
  }

  // Удаление обработчика обновлений
  off(updateType: string, handler: Function): void {
    if (!this.updateHandlers.has(updateType)) return;
    
    const handlers = this.updateHandlers.get(updateType);
    if (handlers) {
      const index = handlers.indexOf(handler);
      if (index !== -1) {
        handlers.splice(index, 1);
      }
    }
  }

  // Уведомление всех обработчиков о новом обновлении
  private notifyUpdateHandlers(updateType: string, update: any): void {
    const handlers = this.updateHandlers.get(updateType);
    if (handlers) {
      handlers.forEach(handler => {
        try {
          handler(update);
        } catch (error) {
          console.error(`Error in update handler for ${updateType}:`, error);
        }
      });
    }
  }

  // Получение списка чатов
  async getChats(limit: number = 100): Promise<any[]> {
    try {
      const result = await this.client.send({
        '@type': 'getChats',
        chat_list: {
          '@type': 'chatListMain',
        },
        limit: limit,
      });
      return result.chat_ids.map((chatId: number) => this.getChat(chatId));
    } catch (error) {
      console.error('Failed to get chats:', error);
      throw error;
    }
  }

  // Получение информации о конкретном чате
  async getChat(chatId: number): Promise<any> {
    try {
      return await this.client.send({
        '@type': 'getChat',
        chat_id: chatId,
      });
    } catch (error) {
      console.error(`Failed to get chat ${chatId}:`, error);
      throw error;
    }
  }

  // Получение сообщений из чата
  async getChatHistory(chatId: number, limit: number = 100): Promise<any[]> {
    try {
      return await this.client.send({
        '@type': 'getChatHistory',
        chat_id: chatId,
        limit: limit,
        offset: 0,
        only_local: false,
      });
    } catch (error) {
      console.error(`Failed to get chat history for ${chatId}:`, error);
      throw error;
    }
  }
  
  // Предоставление доступа к клиенту для внутренних сервисов
  getClient(): any {
    return this.client;
  }
}

// Создание и экспорт синглтона сервиса
const telegramService = new TelegramService();
export default telegramService;
