import React, { useState, useEffect } from 'react';
import { Box, Button, TextField, Typography, Container, Paper, CircularProgress, Alert } from '@mui/material';
import telegramService from '../services/TelegramService';

interface AuthPageProps {
  onAuth: () => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ onAuth }) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [password, setPassword] = useState('');
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [initialized, setInitialized] = useState(false);

  // Инициализация TDLib при загрузке компонента
  useEffect(() => {
    const initTelegram = async () => {
      try {
        setLoading(true);
        await telegramService.initialize();
        setInitialized(true);
        setLoading(false);
      } catch (err) {
        setError('Ошибка инициализации Telegram API');
        setLoading(false);
        console.error('Initialization error:', err);
      }
    };

    initTelegram();

    // Подписка на изменения состояния авторизации
    const handleAuthStateChanged = (authState: string) => {
      console.log('Auth state changed:', authState);
      
      if (authState === 'authorizationStateWaitPhoneNumber') {
        setStep(1);
      } else if (authState === 'authorizationStateWaitCode') {
        setStep(2);
      } else if (authState === 'authorizationStateWaitPassword') {
        setStep(3);
      } else if (authState === 'authorizationStateReady') {
        onAuth();
      }
    };

    telegramService.on('authStateChanged', handleAuthStateChanged);

    return () => {
      telegramService.off('authStateChanged', handleAuthStateChanged);
    };
  }, [onAuth]);

  // Отправка номера телефона
  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    
    try {
      await telegramService.sendPhoneNumber(phoneNumber);
      // Переход к следующему шагу происходит автоматически через обработчик событий
    } catch (err: any) {
      setError(err.message || 'Ошибка отправки номера телефона');
      console.error('Phone submission error:', err);
    } finally {
      setLoading(false);
    }
  };

  // Отправка кода подтверждения
  const handleCodeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    
    try {
      await telegramService.sendVerificationCode(verificationCode);
      // Переход к следующему шагу происходит автоматически через обработчик событий
    } catch (err: any) {
      setError(err.message || 'Неверный код подтверждения');
      console.error('Code submission error:', err);
    } finally {
      setLoading(false);
    }
  };

  // Отправка пароля (для двухфакторной аутентификации)
  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    
    try {
      await telegramService.sendPassword(password);
      // Переход к следующему шагу происходит автоматически через обработчик событий
    } catch (err: any) {
      setError(err.message || 'Неверный пароль');
      console.error('Password submission error:', err);
    } finally {
      setLoading(false);
    }
  };

  if (!initialized && !error) {
    return (
      <Container maxWidth="sm">
        <Box sx={{ mt: 8, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <CircularProgress />
          <Typography variant="body1" sx={{ mt: 2 }}>
            Инициализация Telegram API...
          </Typography>
        </Box>
      </Container>
    );
  }

  return (
    <Container maxWidth="sm">
      <Box sx={{ mt: 8, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Paper elevation={3} sx={{ p: 4, width: '100%' }}>
          <Typography component="h1" variant="h4" align="center" gutterBottom>
            Telegram Deep Insights
          </Typography>
          <Typography variant="body1" align="center" paragraph>
            Анализ скрытых паттернов в переписках Telegram
          </Typography>

          {error && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {error}
            </Alert>
          )}

          {step === 1 && (
            <Box component="form" onSubmit={handlePhoneSubmit} sx={{ mt: 2 }}>
              <TextField
                margin="normal"
                required
                fullWidth
                id="phone"
                label="Номер телефона"
                name="phone"
                autoComplete="tel"
                autoFocus
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="+7XXXXXXXXXX"
                disabled={loading}
              />
              <Button
                type="submit"
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2 }}
                disabled={loading || !phoneNumber}
              >
                {loading ? <CircularProgress size={24} /> : 'Получить код'}
              </Button>
            </Box>
          )}

          {step === 2 && (
            <Box component="form" onSubmit={handleCodeSubmit} sx={{ mt: 2 }}>
              <TextField
                margin="normal"
                required
                fullWidth
                id="code"
                label="Код подтверждения"
                name="code"
                autoFocus
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value)}
                disabled={loading}
              />
              <Button
                type="submit"
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2 }}
                disabled={loading || !verificationCode}
              >
                {loading ? <CircularProgress size={24} /> : 'Подтвердить код'}
              </Button>
              <Button
                fullWidth
                variant="text"
                onClick={() => setStep(1)}
                sx={{ mt: 1 }}
                disabled={loading}
              >
                Изменить номер телефона
              </Button>
            </Box>
          )}

          {step === 3 && (
            <Box component="form" onSubmit={handlePasswordSubmit} sx={{ mt: 2 }}>
              <Typography variant="body2" paragraph>
                Для вашего аккаунта включена двухфакторная аутентификация. Пожалуйста, введите пароль.
              </Typography>
              <TextField
                margin="normal"
                required
                fullWidth
                id="password"
                label="Пароль"
                name="password"
                type="password"
                autoFocus
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={loading}
              />
              <Button
                type="submit"
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2 }}
                disabled={loading || !password}
              >
                {loading ? <CircularProgress size={24} /> : 'Войти'}
              </Button>
              <Button
                fullWidth
                variant="text"
                onClick={() => setStep(1)}
                sx={{ mt: 1 }}
                disabled={loading}
              >
                Начать заново
              </Button>
            </Box>
          )}
        </Paper>
      </Box>
    </Container>
  );
};

export default AuthPage;
