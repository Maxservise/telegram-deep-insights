// Для решения проблемы с Material UI Grid и ListItem
import React from 'react';
import { Box, Typography, Container, Grid as MuiGrid, Paper, CircularProgress, List, ListItem as MuiListItem, ListItemText, ListItemAvatar, Avatar, Divider } from '@mui/material';
import dataExtractionService from '../services/DataExtractionService';

// Создаем обертки для компонентов Material UI, чтобы исправить проблему с типами
const Grid = (props: any) => <MuiGrid {...props} />;
const ListItem = (props: any) => <MuiListItem {...props} />;

const DashboardPage: React.FC = () => {
  const [loading, setLoading] = React.useState(true);
  const [personalChats, setPersonalChats] = React.useState<any[]>([]);
  const [groupChats, setGroupChats] = React.useState<any[]>([]);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    const fetchChats = async () => {
      try {
        setLoading(true);
        const allChats = await dataExtractionService.getAllChats(200);
        
        // Разделяем чаты на личные и групповые
        const personal: any[] = [];
        const groups: any[] = [];
        
        for (const chat of allChats) {
          if (chat.type['@type'] === 'chatTypePrivate') {
            personal.push(chat);
          } else if (
            chat.type['@type'] === 'chatTypeBasicGroup' || 
            chat.type['@type'] === 'chatTypeSupergroup'
          ) {
            groups.push(chat);
          }
        }
        
        setPersonalChats(personal);
        setGroupChats(groups);
      } catch (err: any) {
        console.error('Error fetching chats:', err);
        setError(err.message || 'Ошибка при загрузке чатов');
      } finally {
        setLoading(false);
      }
    };
    
    fetchChats();
  }, []);

  const renderChatList = (chats: any[], title: string) => (
    <Paper elevation={2} sx={{ p: 3, height: '100%' }}>
      <Typography variant="h6" gutterBottom>
        {title}
      </Typography>
      
      {chats.length === 0 ? (
        <Typography variant="body2">
          Чаты не найдены
        </Typography>
      ) : (
        <List sx={{ maxHeight: 400, overflow: 'auto' }}>
          {chats.map((chat) => (
            <React.Fragment key={chat.id}>
              <ListItem button component="a" href={`/chat/${chat.id}`}>
                <ListItemAvatar>
                  <Avatar src={chat.photo?.small?.local?.path || ''}>
                    {chat.title.charAt(0)}
                  </Avatar>
                </ListItemAvatar>
                <ListItemText 
                  primary={chat.title} 
                  secondary={chat.last_message?.content?.text?.text || 'Нет сообщений'} 
                />
              </ListItem>
              <Divider variant="inset" component="li" />
            </React.Fragment>
          ))}
        </List>
      )}
    </Paper>
  );

  if (loading) {
    return (
      <Container maxWidth="lg">
        <Box sx={{ mt: 4, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <CircularProgress />
          <Typography variant="body1" sx={{ mt: 2 }}>
            Загрузка чатов...
          </Typography>
        </Box>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography component="h1" variant="h4" gutterBottom>
          Панель управления
        </Typography>
        <Typography variant="body1" paragraph>
          Добро пожаловать в Telegram Deep Insights. Выберите чат для анализа или просмотрите общую статистику.
        </Typography>
        
        {error && (
          <Typography color="error" sx={{ mb: 2 }}>
            {error}
          </Typography>
        )}
        
        <Grid container spacing={3} sx={{ mt: 2 }}>
          <Grid item xs={12} md={6}>
            {renderChatList(personalChats, 'Личные чаты')}
          </Grid>
          
          <Grid item xs={12} md={6}>
            {renderChatList(groupChats, 'Групповые чаты')}
          </Grid>
          
          <Grid item xs={12}>
            <Paper elevation={2} sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                Общая статистика
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={4}>
                  <Paper elevation={1} sx={{ p: 2, textAlign: 'center' }}>
                    <Typography variant="h4">{personalChats.length}</Typography>
                    <Typography variant="body2">Личных чатов</Typography>
                  </Paper>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <Paper elevation={1} sx={{ p: 2, textAlign: 'center' }}>
                    <Typography variant="h4">{groupChats.length}</Typography>
                    <Typography variant="body2">Групповых чатов</Typography>
                  </Paper>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <Paper elevation={1} sx={{ p: 2, textAlign: 'center' }}>
                    <Typography variant="h4">{personalChats.length + groupChats.length}</Typography>
                    <Typography variant="body2">Всего чатов</Typography>
                  </Paper>
                </Grid>
              </Grid>
            </Paper>
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
};

export default DashboardPage;
