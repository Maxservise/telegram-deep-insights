import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { 
  Box, 
  Typography, 
  Container, 
  Paper, 
  CircularProgress, 
  Tabs, 
  Tab, 
  Grid as MuiGrid, 
  List, 
  ListItem as MuiListItem, 
  ListItemText, 
  Chip,
  Card,
  CardContent,
  Divider
} from '@mui/material';
import { 
  PieChart, 
  Pie, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import dataExtractionService from '../services/DataExtractionService';
import analysisService from '../services/AnalysisService';
import { ChatAnalysisResult } from '../types/AnalysisTypes';

// Создаем обертки для компонентов Material UI, чтобы исправить проблему с типами
const Grid = (props: any) => <MuiGrid {...props} />;
const ListItem = (props: any) => <MuiListItem {...props} />;

// Интерфейс для TabPanel
interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

// Компонент для содержимого вкладки
const TabPanel = (props: TabPanelProps) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`chat-analysis-tabpanel-${index}`}
      aria-labelledby={`chat-analysis-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
};

const ChatAnalysisPage: React.FC = () => {
  const { chatId } = useParams<{ chatId: string }>();
  const [loading, setLoading] = useState(true);
  const [chatData, setChatData] = useState<any>(null);
  const [analysisResult, setAnalysisResult] = useState<ChatAnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [tabValue, setTabValue] = useState(0);

  // Цвета для графиков
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];
  
  // Обработчик изменения вкладки
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  useEffect(() => {
    const fetchAndAnalyzeChat = async () => {
      if (!chatId) return;
      
      try {
        setLoading(true);
        
        // Получаем информацию о чате
        const chatInfo = await dataExtractionService.getChatInfo(parseInt(chatId));
        
        // Подготавливаем данные для анализа
        const preparedData = await dataExtractionService.prepareChatDataForAnalysis(parseInt(chatId));
        setChatData(preparedData);
        
        // Анализируем данные
        const analysis = await analysisService.analyzeChatData(preparedData);
        setAnalysisResult(analysis);
        
      } catch (err: any) {
        console.error('Error analyzing chat:', err);
        setError(err.message || 'Ошибка при анализе чата');
      } finally {
        setLoading(false);
      }
    };
    
    fetchAndAnalyzeChat();
  }, [chatId]);

  if (loading) {
    return (
      <Container maxWidth="lg">
        <Box sx={{ mt: 4, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <CircularProgress />
          <Typography variant="body1" sx={{ mt: 2 }}>
            Загрузка данных чата...
          </Typography>
        </Box>
      </Container>
    );
  }

  if (error) {
    return (
      <Container maxWidth="lg">
        <Box sx={{ mt: 4 }}>
          <Typography color="error" variant="h6">
            {error}
          </Typography>
          <Typography variant="body1" sx={{ mt: 2 }}>
            Пожалуйста, вернитесь на главную страницу и попробуйте выбрать другой чат.
          </Typography>
        </Box>
      </Container>
    );
  }

  if (!chatData || !analysisResult) {
    return (
      <Container maxWidth="lg">
        <Box sx={{ mt: 4 }}>
          <Typography variant="h6">
            Нет данных для анализа
          </Typography>
        </Box>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography component="h1" variant="h4" gutterBottom>
          {chatData.chatInfo.title}
        </Typography>
        
        <Paper sx={{ width: '100%', mb: 2 }}>
          <Tabs
            value={tabValue}
            onChange={handleTabChange}
            indicatorColor="primary"
            textColor="primary"
            variant="scrollable"
            scrollButtons="auto"
          >
            <Tab label="Инсайты" />
            <Tab label="Темы общения" />
            <Tab label="Паттерны взаимодействия" />
            {analysisResult.manipulationTactics && analysisResult.manipulationTactics.length > 0 && (
              <Tab label="Манипулятивные тактики" />
            )}
            {analysisResult.groupDynamics && (
              <Tab label="Групповая динамика" />
            )}
          </Tabs>
          
          {/* Вкладка с инсайтами */}
          <TabPanel value={tabValue} index={0}>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Card>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Ключевые инсайты
                    </Typography>
                    <List>
                      {analysisResult.insights.map((insight, index) => (
                        <ListItem key={index}>
                          <ListItemText primary={insight} />
                        </ListItem>
                      ))}
                    </List>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12}>
                <Card>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Общая статистика
                    </Typography>
                    <Grid container spacing={2}>
                      <Grid item xs={12} sm={4}>
                        <Paper elevation={1} sx={{ p: 2, textAlign: 'center' }}>
                          <Typography variant="h4">{analysisResult.messageCount}</Typography>
                          <Typography variant="body2">Сообщений</Typography>
                        </Paper>
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <Paper elevation={1} sx={{ p: 2, textAlign: 'center' }}>
                          <Typography variant="h4">{analysisResult.topics.length}</Typography>
                          <Typography variant="body2">Тем общения</Typography>
                        </Paper>
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <Paper elevation={1} sx={{ p: 2, textAlign: 'center' }}>
                          <Typography variant="h4">
                            {analysisResult.messageAnalysis.filter(m => m.sentiment === 'позитивный').length}
                          </Typography>
                          <Typography variant="body2">Позитивных сообщений</Typography>
                        </Paper>
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </TabPanel>
          
          {/* Вкладка с темами общения */}
          <TabPanel value={tabValue} index={1}>
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Card>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Распределение тем
                    </Typography>
                    <Box sx={{ height: 300 }}>
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={analysisResult.topics.filter(t => t.frequency > 0)}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="frequency"
                            nameKey="topic"
                            label={({ topic, percent }) => `${topic}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {analysisResult.topics.filter(t => t.frequency > 0).map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Card>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Список тем
                    </Typography>
                    <List>
                      {analysisResult.topics
                        .filter(topic => topic.frequency > 0)
                        .map((topic, index) => (
                          <ListItem key={index}>
                            <ListItemText 
                              primary={topic.topic} 
                              secondary={`Упоминаний: ${topic.frequency}`} 
                            />
                            <Chip 
                              label={`${Math.round((topic.frequency / analysisResult.messageCount) * 100)}%`} 
                              color={index < 3 ? "primary" : "default"} 
                            />
                          </ListItem>
                        ))}
                    </List>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </TabPanel>
          
          {/* Вкладка с паттернами взаимодействия */}
          <TabPanel value={tabValue} index={2}>
            {analysisResult.interactionPatterns && (
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <Card>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>
                        Паттерны взаимодействия
                      </Typography>
                      <List>
                        {analysisResult.interactionPatterns.map((pattern, index) => (
                          <ListItem key={index}>
                            <ListItemText 
                              primary={pattern.description} 
                              secondary={`Пользователь ID: ${pattern.userId}`} 
                            />
                          </ListItem>
                        ))}
                      </List>
                    </CardContent>
                  </Card>
                </Grid>
                
                <Grid item xs={12}>
                  <Card>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>
                        Эмоциональный тон общения
                      </Typography>
                      <Box sx={{ height: 300 }}>
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={[
                              { 
                                name: 'Позитивный', 
                                value: analysisResult.messageAnalysis.filter(m => m.sentiment === 'позитивный').length 
                              },
                              { 
                                name: 'Нейтральный', 
                                value: analysisResult.messageAnalysis.filter(m => m.sentiment === 'нейтральный').length 
                              },
                              { 
                                name: 'Негативный', 
                                value: analysisResult.messageAnalysis.filter(m => m.sentiment === 'негативный').length 
                              }
                            ]}
                            margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Bar dataKey="value" name="Количество сообщений">
                              <Cell fill="#4CAF50" />
                              <Cell fill="#2196F3" />
                              <Cell fill="#F44336" />
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            )}
          </TabPanel>
          
          {/* Вкладка с манипулятивными тактиками */}
          {analysisResult.manipulationTactics && analysisResult.manipulationTactics.length > 0 && (
            <TabPanel value={tabValue} index={3}>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <Card>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>
                        Обнаруженные манипулятивные тактики
                      </Typography>
                      <Typography variant="body2" color="textSecondary" paragraph>
                        Обратите внимание, что это автоматический анализ, который может содержать ложные срабатывания.
                      </Typography>
                      
                      {analysisResult.manipulationTactics.map((tactic, index) => (
                        <Paper key={index} sx={{ p: 2, mb: 2 }}>
                          <Typography variant="subtitle1" gutterBottom>
                            {tactic.tactic} (Пользователь ID: {tactic.userId})
                          </Typography>
                          <Typography variant="body2" color="textSecondary" gutterBottom>
                            Примеры:
                          </Typography>
                          <List>
                            {tactic.examples.map((example, exIndex) => (
                              <ListItem key={exIndex}>
                                <ListItemText 
                                  primary={example} 
                                  primaryTypographyProps={{ 
                                    style: { fontStyle: 'italic', fontSize: '0.9rem' } 
                                  }}
                                />
                              </ListItem>
                            ))}
                          </List>
                        </Paper>
                      ))}
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            </TabPanel>
          )}
          
          {/* Вкладка с групповой динамикой */}
          {analysisResult.groupDynamics && (
            <TabPanel value={tabValue} index={analysisResult.manipulationTactics && analysisResult.manipulationTactics.length > 0 ? 4 : 3}>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Card>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>
                        Лидеры группы
                      </Typography>
                      <List>
                        {analysisResult.groupDynamics.leaders.map((leaderId, index) => (
                          <ListItem key={index}>
                            <ListItemText 
                              primary={`Пользователь ID: ${leaderId}`} 
                              secondary={index === 0 ? "Основной лидер" : "Влиятельный участник"} 
                            />
                            <Chip 
                              label={`#${index + 1}`} 
                              color={index === 0 ? "primary" : "default"} 
                            />
                          </ListItem>
                        ))}
                      </List>
                    </CardContent>
                  </Card>
                </Grid>
                
                <Grid item xs={12} md={6}>
                  <Card>
                    <CardContent>
                      <Typography variant="h6" gutterBottom>
                        Уровень вовлеченности
                      </Typography>
                      <Box sx={{ height: 300 }}>
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={analysisResult.groupDynamics.engagement
                              .slice(0, 10) // Показываем только топ-10 участников
                              .map(item => ({ 
                                name: `ID: ${item.userId}`, 
                                value: item.level 
                              }))}
                            layout="vertical"
                            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis type="number" domain={[0, 10]} />
                            <YAxis dataKey="name" type="category" />
                            <Tooltip />
                            <Legend />
                            <Bar dataKey="value" name="Уровень вовлеченности (0-10)" fill="#8884d8" />
                          </BarChart>
                        </ResponsiveContainer>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
                
                {analysisResult.groupDynamics.subgroups.length > 0 && (
                  <Grid item xs={12}>
                    <Card>
                      <CardContent>
                        <Typography variant="h6" gutterBottom>
                          Подгруппы
                        </Typography>
                        <Grid container spacing={2}>
                          {analysisResult.groupDynamics.subgroups.map((subgroup, index) => (
                            <Grid item xs={12} sm={6} md={4} key={index}>
                              <Paper elevation={1} sx={{ p: 2 }}>
                                <Typography variant="subtitle1" gutterBottom>
                                  Подгруппа #{index + 1}
                                </Typography>
                                <Typography variant="body2" gutterBottom>
                                  Участники: {subgroup.members.join(', ')}
                                </Typography>
                                <Typography variant="body2">
                                  Сплоченность: {Math.round(subgroup.cohesion * 100) / 100}
                                </Typography>
                              </Paper>
                            </Grid>
                          ))}
                        </Grid>
                      </CardContent>
                    </Card>
                  </Grid>
                )}
                
                {analysisResult.groupDynamics.conflicts.length > 0 && (
                  <Grid item xs={12}>
                    <Card>
                      <CardContent>
                        <Typography variant="h6" gutterBottom>
                          Потенциальные конфликты
                        </Typography>
                        <List>
                          {analysisResult.groupDynamics.conflicts.map((conflict, index) => (
                            <ListItem key={index}>
                              <ListItemText 
                                primary={`Между пользователями ${conflict.users.join(' и ')}`} 
                                secondary={`Интенсивность: ${conflict.intensity}`} 
                              />
                            </ListItem>
                          ))}
                        </List>
                      </CardContent>
                    </Card>
                  </Grid>
                )}
              </Grid>
            </TabPanel>
          )}
        </Paper>
      </Box>
    </Container>
  );
};

export default ChatAnalysisPage;
