import React from 'react';
import { Box, Typography, Container, Paper, List, ListItem, ListItemText, Switch, Divider } from '@mui/material';

const SettingsPage: React.FC = () => {
  return (
    <Container maxWidth="md">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography component="h1" variant="h4" gutterBottom>
          Настройки
        </Typography>
        
        <Paper elevation={2} sx={{ p: 3, mt: 3 }}>
          <Typography variant="h6" gutterBottom>
            Приватность
          </Typography>
          
          <List>
            <ListItem>
              <ListItemText 
                primary="Локальная обработка данных" 
                secondary="Обрабатывать данные только на вашем устройстве" 
              />
              <Switch defaultChecked />
            </ListItem>
            <Divider />
            
            <ListItem>
              <ListItemText 
                primary="Шифрование данных" 
                secondary="Хранить все данные в зашифрованном виде" 
              />
              <Switch defaultChecked />
            </ListItem>
            <Divider />
            
            <ListItem>
              <ListItemText 
                primary="Анонимная статистика" 
                secondary="Отправлять анонимную статистику использования для улучшения сервиса" 
              />
              <Switch />
            </ListItem>
          </List>
        </Paper>
        
        <Paper elevation={2} sx={{ p: 3, mt: 3 }}>
          <Typography variant="h6" gutterBottom>
            Параметры анализа
          </Typography>
          
          <List>
            <ListItem>
              <ListItemText 
                primary="Глубокий анализ" 
                secondary="Выполнять более детальный анализ (требует больше ресурсов)" 
              />
              <Switch defaultChecked />
            </ListItem>
            <Divider />
            
            <ListItem>
              <ListItemText 
                primary="Анализ эмоций" 
                secondary="Определять эмоциональный окрас сообщений" 
              />
              <Switch defaultChecked />
            </ListItem>
            <Divider />
            
            <ListItem>
              <ListItemText 
                primary="Анализ манипуляций" 
                secondary="Выявлять потенциальные манипулятивные тактики" 
              />
              <Switch defaultChecked />
            </ListItem>
          </List>
        </Paper>
        
        <Paper elevation={2} sx={{ p: 3, mt: 3 }}>
          <Typography variant="h6" gutterBottom>
            Управление аккаунтом
          </Typography>
          
          <List>
            <ListItem>
              <ListItemText 
                primary="Удалить все данные" 
                secondary="Удалить все сохраненные данные и результаты анализа" 
              />
              <Switch />
            </ListItem>
            <Divider />
            
            <ListItem>
              <ListItemText 
                primary="Выйти из аккаунта" 
                secondary="Выйти из аккаунта Telegram" 
              />
              <Switch />
            </ListItem>
          </List>
        </Paper>
      </Box>
    </Container>
  );
};

export default SettingsPage;
