// Мок-реализация TDWeb для демонстрационных целей
class TdClient {
  constructor(options) {
    this.options = options;
    this.onUpdate = options.onUpdate;
    console.log('TDWeb mock initialized with options:', options);
  }

  send(request) {
    console.log('TDWeb mock received request:', request);
    
    // Имитация ответов на различные запросы
    if (request['@type'] === 'setTdlibParameters') {
      return Promise.resolve({ '@type': 'ok' });
    }
    
    if (request['@type'] === 'setAuthenticationPhoneNumber') {
      // Имитация отправки кода подтверждения
      setTimeout(() => {
        this.onUpdate({
          '@type': 'updateAuthorizationState',
          authorization_state: {
            '@type': 'authorizationStateWaitCode'
          }
        });
      }, 1000);
      return Promise.resolve({ '@type': 'ok' });
    }
    
    if (request['@type'] === 'checkAuthenticationCode') {
      // Имитация успешной проверки кода
      setTimeout(() => {
        this.onUpdate({
          '@type': 'updateAuthorizationState',
          authorization_state: {
            '@type': 'authorizationStateReady'
          }
        });
      }, 1000);
      return Promise.resolve({ '@type': 'ok' });
    }
    
    if (request['@type'] === 'getChats') {
      // Имитация списка чатов
      return Promise.resolve({
        '@type': 'chats',
        chat_ids: [1, 2, 3, 4, 5]
      });
    }
    
    if (request['@type'] === 'getChat') {
      // Имитация информации о чате
      const chatId = request.chat_id;
      if (chatId === 1) {
        return Promise.resolve({
          '@type': 'chat',
          id: 1,
          title: 'Личный чат с Иваном',
          type: { '@type': 'chatTypePrivate', user_id: 100 },
          last_message: {
            content: { text: { text: 'Привет, как дела?' } }
          }
        });
      } else if (chatId === 2) {
        return Promise.resolve({
          '@type': 'chat',
          id: 2,
          title: 'Рабочий чат',
          type: { '@type': 'chatTypeBasicGroup', basic_group_id: 200 },
          last_message: {
            content: { text: { text: 'Обсуждаем новый проект' } }
          }
        });
      } else {
        return Promise.resolve({
          '@type': 'chat',
          id: chatId,
          title: `Чат ${chatId}`,
          type: { '@type': chatId % 2 === 0 ? 'chatTypeBasicGroup' : 'chatTypePrivate', user_id: chatId * 100 },
          last_message: {
            content: { text: { text: 'Последнее сообщение' } }
          }
        });
      }
    }
    
    if (request['@type'] === 'getChatHistory') {
      // Имитация истории сообщений
      const messages = [];
      for (let i = 1; i <= 50; i++) {
        messages.push({
          id: i,
          sender_id: { user_id: i % 2 === 0 ? request.chat_id * 100 : 0 },
          date: Math.floor(Date.now() / 1000) - i * 3600,
          content: {
            text: {
              text: `Сообщение ${i}: ${i % 3 === 0 ? 'Отлично, спасибо!' : i % 3 === 1 ? 'Привет, как дела?' : 'Давай обсудим новый проект'}`
            }
          }
        });
      }
      return Promise.resolve({
        '@type': 'messages',
        messages: messages
      });
    }
    
    if (request['@type'] === 'getUser') {
      // Имитация информации о пользователе
      return Promise.resolve({
        '@type': 'user',
        id: request.user_id,
        first_name: `Пользователь ${request.user_id}`,
        last_name: 'Фамилия',
        username: `user${request.user_id}`,
        status: { '@type': 'userStatusOnline' }
      });
    }
    
    // Для всех остальных запросов возвращаем заглушку
    return Promise.resolve({ '@type': 'ok' });
  }
}

export default TdClient;
