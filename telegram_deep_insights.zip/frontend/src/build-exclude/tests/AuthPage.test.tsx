import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import AuthPage from '../pages/AuthPage';
import { AuthProvider } from '../contexts/AuthContext';

// Mock the TelegramService
jest.mock('../services/TelegramService', () => ({
  __esModule: true,
  default: {
    initialize: jest.fn().mockResolvedValue(undefined),
    on: jest.fn(),
    off: jest.fn(),
    sendPhoneNumber: jest.fn(),
    sendVerificationCode: jest.fn(),
    sendPassword: jest.fn(),
    isAuthenticated: jest.fn().mockReturnValue(false)
  }
}));

describe('AuthPage Component', () => {
  const renderAuthPage = () => {
    render(
      <BrowserRouter>
        <AuthProvider>
          <AuthPage onAuth={() => {}} />
        </AuthProvider>
      </BrowserRouter>
    );
  };

  test('renders authentication form', async () => {
    renderAuthPage();
    
    // Wait for initialization to complete
    await waitFor(() => {
      expect(screen.getByText(/Telegram Deep Insights/i)).toBeInTheDocument();
    });
    
    // Check if phone number input is displayed
    expect(screen.getByLabelText(/Номер телефона/i)).toBeInTheDocument();
    expect(screen.getByText(/Получить код/i)).toBeInTheDocument();
  });
});
