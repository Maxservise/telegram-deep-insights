import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import DashboardPage from '../pages/DashboardPage';

// Mock the DataExtractionService
jest.mock('../services/DataExtractionService', () => ({
  __esModule: true,
  default: {
    getAllChats: jest.fn().mockResolvedValue([
      {
        id: 1,
        title: 'Test Personal Chat',
        type: { '@type': 'chatTypePrivate' },
        last_message: { content: { text: { text: 'Hello world' } } }
      },
      {
        id: 2,
        title: 'Test Group Chat',
        type: { '@type': 'chatTypeBasicGroup' },
        last_message: { content: { text: { text: 'Group message' } } }
      }
    ])
  }
}));

describe('DashboardPage Component', () => {
  test('renders dashboard with chat lists', async () => {
    render(
      <BrowserRouter>
        <DashboardPage />
      </BrowserRouter>
    );
    
    // Initially should show loading state
    expect(screen.getByText(/Загрузка чатов/i)).toBeInTheDocument();
    
    // Wait for chats to load
    await waitFor(() => {
      expect(screen.getByText(/Панель управления/i)).toBeInTheDocument();
    });
    
    // Check if personal and group chat sections are displayed
    expect(screen.getByText(/Личные чаты/i)).toBeInTheDocument();
    expect(screen.getByText(/Групповые чаты/i)).toBeInTheDocument();
    
    // Check if test chats are displayed
    expect(screen.getByText(/Test Personal Chat/i)).toBeInTheDocument();
    expect(screen.getByText(/Test Group Chat/i)).toBeInTheDocument();
    
    // Check if statistics are displayed
    expect(screen.getByText(/Общая статистика/i)).toBeInTheDocument();
  });
});
