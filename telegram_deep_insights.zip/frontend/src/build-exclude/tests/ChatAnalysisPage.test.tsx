import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter, MemoryRouter, Route, Routes } from 'react-router-dom';
import ChatAnalysisPage from '../pages/ChatAnalysisPage';

// Mock the services
jest.mock('../services/DataExtractionService', () => ({
  __esModule: true,
  default: {
    getChatInfo: jest.fn().mockResolvedValue({
      id: 123,
      title: 'Test Chat'
    }),
    prepareChatDataForAnalysis: jest.fn().mockResolvedValue({
      chatInfo: {
        id: 123,
        title: 'Test Chat'
      },
      messages: [
        {
          id: 1,
          sender_id: { user_id: 100 },
          content: { text: { text: 'Hello there' } },
          date: 1617984000
        },
        {
          id: 2,
          sender_id: { user_id: 200 },
          content: { text: { text: 'Hi, how are you?' } },
          date: 1617984060
        }
      ],
      otherUserInfo: {
        id: 200,
        first_name: 'Test',
        last_name: 'User'
      }
    })
  }
}));

jest.mock('../services/AnalysisService', () => ({
  __esModule: true,
  default: {
    analyzeChatData: jest.fn().mockResolvedValue({
      chatId: 123,
      chatType: 'personal',
      messageCount: 2,
      messageAnalysis: [
        {
          messageId: 1,
          userId: 100,
          text: 'Hello there',
          date: new Date(1617984000 * 1000),
          sentiment: 'нейтральный',
          sentimentScore: 0
        },
        {
          messageId: 2,
          userId: 200,
          text: 'Hi, how are you?',
          date: new Date(1617984060 * 1000),
          sentiment: 'позитивный',
          sentimentScore: 1
        }
      ],
      topics: [
        { topic: 'приветствие', frequency: 2 }
      ],
      interactionPatterns: [
        {
          userId: 200,
          patternType: 'responseTime',
          value: 60,
          description: 'Среднее время ответа: 1 мин.'
        }
      ],
      insights: [
        'Общение сбалансировано: вы отправляете 50% сообщений, ваш собеседник - 50%.'
      ]
    })
  }
}));

describe('ChatAnalysisPage Component', () => {
  test('renders chat analysis with results', async () => {
    render(
      <MemoryRouter initialEntries={['/chat/123']}>
        <Routes>
          <Route path="/chat/:chatId" element={<ChatAnalysisPage />} />
        </Routes>
      </MemoryRouter>
    );
    
    // Initially should show loading state
    expect(screen.getByText(/Загрузка данных чата/i)).toBeInTheDocument();
    
    // Wait for analysis to complete
    await waitFor(() => {
      expect(screen.getByText(/Test Chat/i)).toBeInTheDocument();
    });
    
    // Check if tabs are displayed
    expect(screen.getByText(/Инсайты/i)).toBeInTheDocument();
    expect(screen.getByText(/Темы общения/i)).toBeInTheDocument();
    expect(screen.getByText(/Паттерны взаимодействия/i)).toBeInTheDocument();
    
    // Check if insights are displayed
    expect(screen.getByText(/Общение сбалансировано/i)).toBeInTheDocument();
  });
});
