import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import AuthPage from './pages/AuthPage';
import DashboardPage from './pages/DashboardPage';
import ChatAnalysisPage from './pages/ChatAnalysisPage';
import SettingsPage from './pages/SettingsPage';
import { useAuth, AuthGuard } from './contexts/AuthContext';

const App: React.FC = () => {
  const { isAuthenticated } = useAuth();

  return (
    <Router>
      <Routes>
        <Route path="/" element={
          isAuthenticated ? <Navigate to="/dashboard" /> : <AuthPage onAuth={() => {}} />
        } />
        <Route path="/dashboard" element={
          <AuthGuard>
            <DashboardPage />
          </AuthGuard>
        } />
        <Route path="/chat/:chatId" element={
          <AuthGuard>
            <ChatAnalysisPage />
          </AuthGuard>
        } />
        <Route path="/settings" element={
          <AuthGuard>
            <SettingsPage />
          </AuthGuard>
        } />
      </Routes>
    </Router>
  );
};

export default App;
